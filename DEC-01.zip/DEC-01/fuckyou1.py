
# Python Auto Dis Parser 1.1.0
# Author : HTR-TECH | TAHMID RAYAT
# https://linktr.ee/tahmid.rayat
# https://fb.me/tahmid.rayat.official
# ------------------------------------------
# Embedded File   : fuck.py
# Python Bytecode : 2.7 (62211)
# Decompiled at   : Fri Mar 31 16:00:25 2023
# ------------------------------------------


# Okay Decompiling fuck.py
