import os
import sys
import time
import uuid
import marshal
import base64
import datetime

ua=[]
cp=[]
ok=[]
loop=+1

#......logo.......#

logo="""

ariyan momim
"""
#.....main.....#

def main():
	os.system("clear")
	print(logo)
	print(" ")
	print("[1] youtude thanel link")
	print("[0] exit tools")
	print(57*"-")
	momin=input(" CHOOSE :")
	if momin in ["1","01"]:
		os.system('xdg-open https://www.facebook.com/Saimonk189')
		
	elif momin in ["0","00"]:
		exit()
		


		
main()
		
